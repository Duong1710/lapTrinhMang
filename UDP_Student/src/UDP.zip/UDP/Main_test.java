/*
[Mã câu hỏi (qCode): qFJkqFwA].  Một chương trình server cho phép giao tiếp qua giao thức UDP tại cổng 2209. 
Yêu cầu là xây dựng một chương trình client trao đổi thông tin với server theo kịch bản sau:
Đối tượng trao đổi là thể hiện của lớp UDP.Student được mô tả:
•	Tên đầy đủ lớp: UDP.Student
•	Các thuộc tính: id String,code String, name String, email String
•	02 Hàm khởi tạo: 
o	public Student(String id, String code, String name, String email)
o	public Student(String code)
•	Trường dữ liệu: private static final long serialVersionUID = 20171107
Thực hiện:
•       Gửi thông điệp là một chuỗi chứa mã sinh viên và mã câu hỏi theo định dạng “;studentCode;qCode”. 
Ví dụ: “;B15DCCN001;EE29C059”
b.	Nhận thông điệp chứa: 08 byte đầu chứa chuỗi requestId, các byte còn lại chứa một đối tượng là 
thể hiện của lớp Student từ server. Trong đó, các thông tin được thiết lập gồm id và name.
c.	Yêu cầu:
-	Chuẩn hóa tên theo quy tắc: Chữ cái đầu tiên in hoa, các chữ cái còn lại in thường và gán lại thuộc tính name của đối tượng
-	Tạo email ptit.edu.vn từ tên người dùng bằng cách lấy tên và các chữ cái bắt đầu của họ và tên đệm. 
Ví dụ: nguyen van tuan nam -> namnvt@ptit.edu.vn. Gán giá trị này cho thuộc tính email của đối tượng nhận được
-	Gửi thông điệp chứa đối tượng xử lý ở bước c lên Server với cấu trúc: 08 byte đầu chứa chuỗi requestId 
và các byte còn lại chứa đối tượng Student đã được sửa đổi.
d.	Đóng socket và kết thúc chương trình.
 */
package UDP;

import java.util.*;
import java.io.*;
import java.net.*;
public class Main_test {
     public static String formatName(String s){
        String[] words = s.trim().split("\\s+");
        String res = "";
        for(String w : words){
            StringBuilder sb = new StringBuilder(w.toLowerCase());
            sb.replace(0, 1, Character.toUpperCase(sb.charAt(0)) + "");
            res += sb.toString() + " ";
        }
        return res.trim();
    }
    public static String setEmail(String s){
        List<String> words = new ArrayList<>(Arrays.asList(s.toLowerCase().split(" ")));
        String email = words.getLast();
        for(int i=0;i<words.size()-1;i++){
            email += words.get(i).charAt(0);
        }
        email += "@ptit.edu.vn";
        return email;
    }
    public static void main(String[] args) throws Exception {
        // Phần này vẫn giống với UDP datatype
        // Gửi dữ liệu
        String host = "203.162.10.109";
        int port = 2209;
        String ms1 = ";B22DCCN169;qFJkqFwA";
        DatagramSocket sk = new DatagramSocket();
        InetAddress sA = InetAddress.getByName(host);
        DatagramPacket out1 = new DatagramPacket(ms1.getBytes(), ms1.length(), sA, port);
        sk.send(out1);
        // Nhận dữ liệu
        byte[] bs1 = new byte[1024];
        DatagramPacket in = new DatagramPacket(bs1, bs1.length);
        sk.receive(in);
        // String requestId nhận 8 byte
        String rid = new String(in.getData(), 0, 8);
        System.out.println(rid);
        // Dữ liệu xử lí: từ byte 8 - byte cuối. Độ lớn = length - 8
        ByteArrayInputStream bais = new ByteArrayInputStream(in.getData(), 8, in.getLength()-8);
        // Ép kiểu mảng byte -> Đối tương Object
        ObjectInputStream ois = new ObjectInputStream(bais);
        // Ép kiểu Object -> Student. Đọc dư liệu
        Student s = (Student) ois.readObject();
        System.out.println(s);
        s.name = formatName(s.name);
        s.email = setEmail(s.name);
        System.out.println(s);
        // Nộp bài
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(baos);
        // Ghi dữ liệu vào trong baos
        oos.writeObject(s);
        oos.flush();
        
        // Tạo mảng send data
        byte[] bs2 = new byte[8 + baos.size()];
        System.arraycopy(rid.getBytes(), 0, bs2, 0, 8);
        System.arraycopy(baos.toByteArray(), 0, bs2, 8, baos.size());
        DatagramPacket out2 = new DatagramPacket(bs2, bs2.length, sA, port);
        sk.send(out2);
        sk.close();
    }
}